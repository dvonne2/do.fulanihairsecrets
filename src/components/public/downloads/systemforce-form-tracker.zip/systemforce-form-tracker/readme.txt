=== SystemForce Form Tracker ===
Contributors: SystemForce
Tags: forms, leads, abandoned cart, gravity forms, elementor, wpforms
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

Capture partial form data (abandoned carts) from ANY form builder and send to SystemForce ERP.

== Description ==

This plugin captures form data AS customers type - not just when they submit. Perfect for recovering abandoned orders!

**How It Works:**
1. Customer visits your order form
2. They type their phone number → Instantly sent to your ERP
3. They add their name → ERP updated
4. They leave without submitting → You still have their info!

**Compatible With:**
* Gravity Forms
* Elementor Forms
* WPForms
* Contact Form 7
* Any HTML form

== Installation ==

1. Upload the plugin to `/wp-content/plugins/`
2. Activate the plugin
3. Go to Settings → SystemForce Tracker
4. Enter your Webhook Code from your ERP dashboard
5. Enable tracking and Save

== Changelog ==

= 1.0.0 =
* Initial release
* Automatic field detection
* UTM parameter tracking
* Works with all major form builders
