<?php
/**
 * Plugin Name: SystemForce Form Tracker
 * Plugin URI: https://systemforce.ng
 * Description: Captures partial form data (abandoned carts) and sends to SystemForce ERP. Works with Gravity Forms, Elementor, WPForms, and any HTML form.
 * Version: 1.0.0
 * Author: SystemForce
 * Author URI: https://systemforce.ng
 * License: GPL v2 or later
 * 
 * HOW IT WORKS:
 * 1. Install this plugin on your WordPress site
 * 2. Go to Settings → SystemForce Tracker
 * 3. Enter your Webhook Code from your ERP dashboard
 * 4. Save - Partial leads are now captured automatically!
 * 
 * When a customer types their phone number in ANY form on your site,
 * that data is immediately sent to your SystemForce ERP - even if
 * they don't submit the form!
 */

if (!defined('ABSPATH')) exit;

class SystemForce_Form_Tracker {
    
    private static $instance = null;
    private $option_name = 'sf_tracker_settings';
    
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_footer', array($this, 'output_tracker_script'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'settings_link'));
    }
    
    public function settings_link($links) {
        $settings = '<a href="' . admin_url('options-general.php?page=sf-tracker') . '">Settings</a>';
        array_unshift($links, $settings);
        return $links;
    }
    
    public function add_settings_page() {
        add_options_page(
            'SystemForce Tracker',
            'SystemForce Tracker',
            'manage_options',
            'sf-tracker',
            array($this, 'render_settings_page')
        );
    }
    
    public function register_settings() {
        register_setting($this->option_name, $this->option_name, array($this, 'sanitize_settings'));
        
        add_settings_section('sf_main', 'Webhook Configuration', function() {
            echo '<p>Connect your forms to SystemForce ERP to capture leads as customers fill out forms.</p>';
        }, 'sf-tracker');
        
        add_settings_field('webhook_code', 'Webhook Code', array($this, 'field_webhook_code'), 'sf-tracker', 'sf_main');
        add_settings_field('erp_url', 'ERP URL', array($this, 'field_erp_url'), 'sf-tracker', 'sf_main');
        add_settings_field('enabled', 'Enable Tracking', array($this, 'field_enabled'), 'sf-tracker', 'sf_main');
    }
    
    public function field_webhook_code() {
        $options = get_option($this->option_name);
        $value = $options['webhook_code'] ?? '';
        echo '<input type="text" name="' . $this->option_name . '[webhook_code]" value="' . esc_attr($value) . '" class="regular-text" placeholder="e.g., fhg-a1b2c3d4" />';
        echo '<p class="description">Your webhook code from SystemForce ERP dashboard</p>';
    }
    
    public function field_erp_url() {
        $options = get_option($this->option_name);
        $value = $options['erp_url'] ?? 'https://systemforce.ng';
        echo '<input type="url" name="' . $this->option_name . '[erp_url]" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">Your SystemForce ERP URL (default: https://systemforce.ng)</p>';
    }
    
    public function field_enabled() {
        $options = get_option($this->option_name);
        $checked = !empty($options['enabled']) ? 'checked' : '';
        echo '<label><input type="checkbox" name="' . $this->option_name . '[enabled]" value="1" ' . $checked . ' /> Enable partial lead capture</label>';
    }
    
    public function sanitize_settings($input) {
        return array(
            'webhook_code' => sanitize_text_field($input['webhook_code'] ?? ''),
            'erp_url' => esc_url_raw($input['erp_url'] ?? 'https://systemforce.ng'),
            'enabled' => !empty($input['enabled']) ? 1 : 0,
        );
    }
    
    public function render_settings_page() {
        $options = get_option($this->option_name);
        $configured = !empty($options['webhook_code']) && !empty($options['enabled']);
        ?>
        <div class="wrap">
            <h1><span style="color: #f97316;">●</span> SystemForce Form Tracker</h1>
            
            <?php if ($configured): ?>
            <div class="notice notice-success"><p><strong>✓ Active!</strong> Partial leads are being captured from your forms.</p></div>
            <?php else: ?>
            <div class="notice notice-warning"><p><strong>⚠ Not Configured</strong> Enter your webhook code below to start.</p></div>
            <?php endif; ?>
            
            <div style="background:#fff;padding:20px;border:1px solid #ccd0d4;border-radius:4px;margin:20px 0;max-width:700px;">
                <h2 style="margin-top:0;">How It Works</h2>
                <ol style="line-height:2;">
                    <li>Customer visits your order form</li>
                    <li><strong>As they type their phone</strong> → Lead created in ERP</li>
                    <li><strong>As they fill more fields</strong> → Lead updated</li>
                    <li><strong>If they leave without submitting</strong> → You still have their info!</li>
                </ol>
                <p style="background:#e7f3ff;padding:12px;border-radius:4px;">
                    💡 <strong>This captures abandoned forms!</strong> Even if they don't click submit, you get their phone number instantly.
                </p>
            </div>
            
            <form method="post" action="options.php">
                <?php
                settings_fields($this->option_name);
                do_settings_sections('sf-tracker');
                submit_button('Save Settings');
                ?>
            </form>
            
            <?php if ($configured): ?>
            <div style="background:#f6f7f7;padding:20px;border:1px solid #ccd0d4;border-radius:4px;margin:20px 0;max-width:400px;">
                <h3 style="margin-top:0;">Connection Status</h3>
                <table class="widefat">
                    <tr><td><strong>Status</strong></td><td><span style="color:green;">● Connected</span></td></tr>
                    <tr><td><strong>Webhook</strong></td><td><code><?php echo esc_html($options['webhook_code']); ?></code></td></tr>
                    <tr><td><strong>ERP</strong></td><td><?php echo esc_html($options['erp_url']); ?></td></tr>
                </table>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    public function output_tracker_script() {
        $options = get_option($this->option_name);
        
        if (empty($options['webhook_code']) || empty($options['enabled']) || is_admin()) {
            return;
        }
        
        $webhook_url = trailingslashit($options['erp_url']) . 'wp-json/systemforce/v1/webhook/' . $options['webhook_code'];
        ?>
        <script>
        (function(){
            var WEBHOOK = <?php echo json_encode($webhook_url); ?>;
            var sent = {};
            var timers = {};
            var sid = 'sf_' + Math.random().toString(36).substr(2,9);
            
            // Get UTM params
            var params = {};
            location.search.substring(1).split('&').forEach(function(p){
                var kv = p.split('=');
                if(kv[0]) params[kv[0]] = decodeURIComponent(kv[1]||'');
            });
            
            // Field detection patterns
            var patterns = {
                phone: /phone|tel|mobile|whatsapp/i,
                name: /name|fullname/i,
                email: /email|mail/i,
                address: /address|street|delivery/i,
                state: /state|region|province/i,
                lga: /lga|city|area|district/i,
                landmark: /landmark|busstop|direction/i
            };
            
            function detect(input) {
                var str = (input.name||'') + (input.id||'') + (input.placeholder||'');
                for(var k in patterns) if(patterns[k].test(str)) return k;
                if(input.type==='tel') return 'phone';
                if(input.type==='email') return 'email';
                return null;
            }
            
            function isValidPhone(p) {
                var n = (p||'').replace(/\D/g,'');
                return n.length >= 10 && n.length <= 14;
            }
            
            function send(data) {
                if(!data.phone || !isValidPhone(data.phone)) return;
                var key = JSON.stringify(data);
                if(sent[key]) return;
                
                data.session_id = sid;
                data.page_url = location.href;
                data.utm_source = params.utm_source || '';
                data.utm_medium = params.utm_medium || '';
                data.utm_campaign = params.utm_campaign || '';
                data.source = 'form_tracker';
                
                if(navigator.sendBeacon) {
                    navigator.sendBeacon(WEBHOOK, new Blob([JSON.stringify(data)], {type:'application/json'}));
                } else {
                    fetch(WEBHOOK, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data), keepalive:true});
                }
                sent[key] = 1;
            }
            
            function collect(form) {
                var data = {};
                form.querySelectorAll('input,select,textarea').forEach(function(el){
                    if(el.type==='hidden'||el.type==='submit'||!el.value.trim()) return;
                    var t = detect(el);
                    if(t) data[t] = el.value.trim();
                });
                return data;
            }
            
            function track(form) {
                var fid = form.id || 'f' + Math.random().toString(36).substr(2,4);
                form.querySelectorAll('input,select,textarea').forEach(function(el){
                    if(el.type==='hidden'||el.type==='submit') return;
                    el.addEventListener('blur', function(){
                        clearTimeout(timers[fid]);
                        timers[fid] = setTimeout(function(){
                            var d = collect(form);
                            if(d.phone) send(d);
                        }, 1200);
                    });
                });
            }
            
            function init() {
                document.querySelectorAll('form').forEach(function(f){
                    var action = (f.action||'').toLowerCase();
                    if(action.indexOf('wp-login')>-1 || action.indexOf('wp-admin')>-1) return;
                    if(f.getAttribute('role')==='search') return;
                    track(f);
                });
            }
            
            if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init);
            else init();
            
            // Re-init for AJAX forms
            new MutationObserver(function(){ setTimeout(init,100); }).observe(document.body, {childList:true,subtree:true});
            
            // Capture on page leave
            window.addEventListener('beforeunload', function(){
                document.querySelectorAll('form').forEach(function(f){
                    var d = collect(f);
                    if(d.phone) send(d);
                });
            });
        })();
        </script>
        <?php
    }
}

add_action('plugins_loaded', function() {
    SystemForce_Form_Tracker::instance();
});
